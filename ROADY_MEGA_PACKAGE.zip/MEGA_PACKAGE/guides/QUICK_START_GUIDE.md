# 🚀 ROADY Quick Start Guide

## Welcome to ROADY!

This guide will get you from zero to running ROADY in **15 minutes**.

---

## 📋 Prerequisites

Before starting, make sure you have:

- [ ] Docker & Docker Compose installed
- [ ] Git installed
- [ ] At least one LLM API key (Anthropic, OpenAI, or Google)
- [ ] 4GB+ RAM available
- [ ] PostgreSQL client (optional, for direct DB access)

---

## ⚡ Quick Setup (5 minutes)

### Step 1: Clone & Setup

```bash
# Clone ROADY
git clone https://github.com/your-org/roady.git
cd roady

# Copy environment template
cp .env.template .env

# Edit with your API keys
nano .env  # or use your favorite editor
```

### Step 2: Add Your API Keys

Edit `.env` and add at least ONE API key:

```bash
# Required: Choose at least ONE
ANTHROPIC_API_KEY=sk-ant-xxxxx    # Recommended
OPENAI_API_KEY=sk-xxxxx
GOOGLE_API_KEY=xxxxx

# Optional
COHERE_API_KEY=
DEEPSEEK_API_KEY=
```

### Step 3: Launch!

```bash
# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

### Step 4: Access ROADY

Open your browser:

- **Frontend:** http://localhost:3000
- **API Docs:** http://localhost:8000/docs
- **API:** http://localhost:8000

---

## 👤 First Login

### Default Admin Account

```
Email: admin@roady.ai
Password: admin123
```

**⚠️ IMPORTANT:** Change this password immediately in production!

### Change Password

1. Go to Settings → Account
2. Click "Change Password"
3. Enter new password
4. Save

---

## 🤖 Activate Your First Agent

### Option 1: Quick Start Pack (Recommended)

1. Go to **Dashboard**
2. Click **"Activate Agent Pack"**
3. Choose **"Content Creator Pack"**
   - Includes: Copywriter, Blog Writer, SEO Specialist
   - Cost: ~$25/month
4. Click **"Activate Pack"**

### Option 2: Individual Agent

1. Go to **Agents** → **Browse All**
2. Search for agent (e.g., "Copywriter")
3. Click **"Activate"**
4. Configure:
   - **Primary LLM:** Claude Sonnet 4 (recommended)
   - **Monthly Budget:** $10
   - **Quality Threshold:** 3.5
5. Click **"Activate Agent"**

---

## 📝 Create Your First Task

### Via Web UI

1. Click **"+ New Task"** in dashboard
2. Fill in:
   ```
   Task Name: Write welcome email
   Description: Write a friendly welcome email for new users
   Priority: Medium
   ```
3. Click **"Submit"**
4. Wait 10-30 seconds
5. View result!

### Via API

```bash
curl -X POST http://localhost:8000/api/tasks \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "task_name": "Write welcome email",
    "task_description": "Write a friendly welcome email for new users",
    "priority": "medium"
  }'
```

### Via CLI

```bash
# Install CLI
pip install roady-cli

# Create task
roady task create \
  --name "Write welcome email" \
  --description "Write a friendly welcome email" \
  --priority medium
```

---

## 💰 Set Your Budget

### Configure Monthly Budget

1. Go to **Settings** → **Budget**
2. Set **Monthly Limit:** $100 (or your amount)
3. Configure **Alerts:**
   - ✅ Alert at 70%
   - ✅ Alert at 85%
   - ✅ Alert at 95%
4. Choose **Action at 100%:**
   - Recommended: "Auto-Optimize"
5. Click **"Save"**

### Budget Allocation

#### Per Department
```
Creative: $40/month (40%)
Marketing: $30/month (30%)
Technology: $30/month (30%)
```

#### Per Agent
```
Copywriter: $15/month
Blog Writer: $10/month
SEO Specialist: $10/month
```

---

## 🎯 Configure Fallback LLMs

**Why?** If primary LLM fails, ROADY automatically tries backups.

### For Each Agent

1. Go to **Agents** → Select agent
2. Click **"Configure"**
3. Set **Fallback Chain:**
   ```
   Primary: Claude Sonnet 4
   Fallback 1: GPT-4o
   Fallback 2: Gemini Flash
   Fallback 3: Local Ollama (if configured)
   ```
4. Click **"Save"**

---

## 📊 Monitor Performance

### Dashboard Overview

Your dashboard shows:

- **Active Agents:** 5/168
- **Budget Used:** $23.50/$100 (24%)
- **Tasks Today:** 47
- **Avg Quality:** 4.3/5.0

### Key Metrics to Watch

1. **Budget Usage:** Keep below 85% to avoid auto-optimization
2. **Quality Ratings:** Above 3.5 is good, below needs investigation
3. **Fallback Rate:** Below 5% is healthy
4. **Task Success Rate:** Above 90% is excellent

---

## 🔧 Common Tasks

### View All Tasks

```bash
# Web UI
Dashboard → Recent Tasks

# CLI
roady task list --status all

# API
GET /api/tasks?limit=50
```

### Check Agent Performance

```bash
# Web UI
Agents → [Agent Name] → Performance

# CLI
roady agent stats copywriter --days 30

# API
GET /api/agents/copywriter/performance?days=30
```

### View Cost Breakdown

```bash
# Web UI
Budget → Cost Analysis

# CLI
roady budget report --period month

# API
GET /api/analytics/costs?period=30d
```

### Deactivate Agent

```bash
# Web UI
Agents → [Agent] → Deactivate

# CLI
roady agent deactivate copywriter

# API
POST /api/agents/copywriter/deactivate
```

---

## 🚨 Troubleshooting

### Problem: Services won't start

**Solution:**
```bash
# Check Docker status
docker ps

# View logs
docker-compose logs

# Restart services
docker-compose restart

# Nuclear option
docker-compose down
docker-compose up -d
```

### Problem: Can't connect to database

**Solution:**
```bash
# Check PostgreSQL
docker-compose logs postgres

# Test connection
docker-compose exec postgres psql -U roady_user roady

# If connection refused, check port 5432
netstat -an | grep 5432
```

### Problem: LLM API errors

**Solution:**
```bash
# Check API keys in .env
cat .env | grep API_KEY

# Test Anthropic
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01"

# Check provider status
roady provider test anthropic
```

### Problem: Agent not responding

**Solution:**
```bash
# Check agent status
roady agent status copywriter

# View agent logs
roady agent logs copywriter --tail 50

# Restart agent
roady agent restart copywriter
```

### Problem: Out of budget

**Solution:**
```bash
# Check current spend
roady budget status

# Increase budget
roady budget set --limit 200

# Or optimize automatically
roady budget optimize --auto
```

---

## 📚 Next Steps

### After Quick Start

1. ✅ Read **Advanced Configuration Guide**
2. ✅ Explore **All 168 Agents**
3. ✅ Create **Custom Workflows**
4. ✅ Set up **Integrations** (Slack, Gmail, etc.)
5. ✅ Configure **Webhooks** for automation

### Learn More

- **Documentation:** http://docs.roady.ai
- **Tutorials:** http://docs.roady.ai/tutorials
- **Community:** http://discord.gg/roady
- **GitHub:** http://github.com/your-org/roady

---

## 🎓 Key Concepts

### Agents

**What:** AI workers that perform specific tasks
**Types:** 
- L0: System (Core Orchestrator)
- L1: Directors (18 departments)
- L2: Specialists (148 experts)

### LLM Router

**What:** Intelligent system that selects best LLM for each task
**Features:**
- Multi-provider support
- Automatic fallback
- Budget optimization
- Quality monitoring

### Workflows

**What:** Pre-defined sequences of agent actions
**Example:** Blog Post Creation
1. Writer creates draft
2. SEO Specialist optimizes
3. Editor reviews
4. Publisher posts

### Budget System

**What:** Real-time cost tracking and optimization
**Levels:**
- Global (your total budget)
- Per-provider (per LLM provider)
- Per-agent (per individual agent)
- Per-department (per team)

---

## 💡 Pro Tips

### 1. Start Small
Don't activate all 168 agents! Start with 5-10 for your primary use case.

### 2. Use Agent Packs
Pre-configured packs save time and are optimized for common use cases.

### 3. Monitor Quality
Check agent quality ratings weekly. Upgrade LLMs if quality drops.

### 4. Set Fallbacks
Always configure fallback LLMs. This ensures 99.9%+ uptime.

### 5. Enable Caching
Prompt caching can save 50%+ on costs for repeated patterns.

### 6. Use Local LLMs
For sensitive data, use Ollama (local) - it's free and private.

### 7. Batch Tasks
Submit similar tasks together for better efficiency.

### 8. Review Budgets Monthly
Adjust budgets based on actual usage, not estimates.

---

## ⚙️ Configuration Files

### Environment Variables (.env)

```bash
# Database
DATABASE_URL=postgresql://roady_user:password@postgres:5432/roady

# LLM Providers
ANTHROPIC_API_KEY=sk-ant-xxxxx
OPENAI_API_KEY=sk-xxxxx
GOOGLE_API_KEY=xxxxx

# Redis
REDIS_URL=redis://redis:6379

# Security
SECRET_KEY=your-secret-key-here
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# Features
ENABLE_CACHING=true
ENABLE_WEBHOOKS=true
ENABLE_ANALYTICS=true

# Limits
MAX_AGENTS_PER_USER=50
MAX_TASKS_PER_HOUR=1000
```

### Docker Compose (docker-compose.yml)

Already configured! But you can customize:

```yaml
services:
  backend:
    environment:
      - WORKERS=4  # Increase for more concurrent tasks
      
  postgres:
    environment:
      - POSTGRES_MAX_CONNECTIONS=100  # Adjust as needed
```

---

## 📞 Support

### Get Help

- **Documentation:** http://docs.roady.ai
- **Discord:** http://discord.gg/roady
- **Email:** support@roady.ai
- **GitHub Issues:** http://github.com/your-org/roady/issues

### Report Bugs

```bash
# Via CLI
roady bug-report --describe "Your issue"

# Via GitHub
# Open issue at github.com/your-org/roady/issues
```

---

## ✅ Checklist

Use this checklist to ensure proper setup:

### Installation
- [ ] Docker installed and running
- [ ] Repository cloned
- [ ] .env file configured with API keys
- [ ] Services started (docker-compose up -d)
- [ ] All containers healthy (docker-compose ps)

### Configuration
- [ ] Changed default admin password
- [ ] Set monthly budget limit
- [ ] Configured budget alerts
- [ ] At least one LLM provider connected

### First Steps
- [ ] Activated first agent or agent pack
- [ ] Created and completed first task
- [ ] Reviewed dashboard metrics
- [ ] Configured fallback LLMs

### Optional but Recommended
- [ ] Configured webhooks
- [ ] Set up Slack notifications
- [ ] Created custom workflow
- [ ] Enabled prompt caching
- [ ] Configured backups

---

## 🎉 Congratulations!

You're now ready to use ROADY! 🚀

### What You Can Do Now

✅ Automate content creation
✅ Build marketing campaigns
✅ Develop software
✅ Analyze data
✅ Manage construction projects
✅ Handle customer service
✅ And 168 more use cases!

---

**Need more help?** Check out the **Advanced Configuration Guide** or join our **Discord community**!

**Happy automating! 🤖**
