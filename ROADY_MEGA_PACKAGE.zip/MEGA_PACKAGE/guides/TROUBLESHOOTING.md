# 🔧 ROADY Troubleshooting Guide

Common issues and how to solve them quickly.

---

## 🚨 Services Won't Start

### Problem: Docker Compose Fails

**Symptoms:**
```
ERROR: Couldn't connect to Docker daemon
```

**Solutions:**

1. **Check Docker is running:**
```bash
docker ps
# If error, start Docker desktop/daemon
```

2. **Check ports aren't in use:**
```bash
# Check if ports 5432, 6379, 8000, 3000 are free
netstat -an | grep -E '5432|6379|8000|3000'

# Kill processes using those ports
lsof -ti:5432 | xargs kill -9
```

3. **Reset Docker:**
```bash
docker-compose down -v
docker system prune -a
docker-compose up -d
```

---

## 🗄️ Database Connection Issues

### Problem: Can't Connect to PostgreSQL

**Error:**
```
psycopg2.OperationalError: could not connect to server
```

**Solutions:**

1. **Check PostgreSQL container:**
```bash
docker-compose logs postgres
docker-compose ps postgres
```

2. **Test connection:**
```bash
docker-compose exec postgres psql -U roady_user roady
# Should connect successfully
```

3. **Check credentials in .env:**
```bash
cat .env | grep POSTGRES
# Verify password matches docker-compose.yml
```

4. **Restart database:**
```bash
docker-compose restart postgres
# Wait 10 seconds
docker-compose ps postgres  # Should show "healthy"
```

---

## 🤖 LLM API Errors

### Problem: Anthropic API Error

**Error:**
```
anthropic.RateLimitError: 429 Too Many Requests
```

**Solutions:**

1. **Check API key:**
```bash
# Verify key is valid
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -d '{"model":"claude-3-haiku-20240307","max_tokens":10,"messages":[{"role":"user","content":"Hi"}]}'
```

2. **Wait and retry:**
```
Rate limits reset after 1 minute
Configure fallback LLM to avoid this
```

3. **Check quota:**
```
Visit console.anthropic.com/settings/limits
Verify you have credits remaining
```

### Problem: Invalid API Key

**Error:**
```
authentication_error: invalid x-api-key
```

**Solution:**
```bash
# Update .env with correct key
nano .env
# Update ANTHROPIC_API_KEY=sk-ant-xxxxx

# Restart backend
docker-compose restart backend
```

---

## 💰 Budget Issues

### Problem: Over Budget

**Error:**
```
BudgetExceededError: Monthly limit reached
```

**Solutions:**

1. **Check current spend:**
```bash
roady budget status
# Or via API: GET /api/budget/status
```

2. **Increase budget:**
```bash
# Via CLI
roady budget set --limit 200

# Or in UI: Settings → Budget → Increase Limit
```

3. **Enable auto-optimization:**
```bash
# Switch to cheaper models automatically
roady budget optimize --auto
```

4. **Pause non-critical agents:**
```bash
roady agent pause --department creative
# Keep only essential agents running
```

---

## 🔴 Agent Not Responding

### Problem: Agent Stuck on Task

**Symptoms:**
- Task shows "in_progress" for >10 minutes
- No output generated

**Solutions:**

1. **Check agent logs:**
```bash
docker-compose logs backend | grep agent_id
# Look for errors
```

2. **Check LLM connectivity:**
```bash
roady provider test anthropic
roady provider test openai
```

3. **Restart agent:**
```bash
# Cancel stuck task
roady task cancel task_12345

# Restart agent
roady agent restart copywriter
```

4. **Check fallback configuration:**
```
Ensure fallback LLMs are configured
Agent may be stuck if all LLMs fail
```

---

## ⚡ Performance Issues

### Problem: Slow Response Times

**Symptoms:**
- Tasks taking >2 minutes
- API responses slow

**Solutions:**

1. **Check system resources:**
```bash
docker stats
# Look for high CPU/Memory usage
```

2. **Increase Docker resources:**
```
Docker Desktop → Settings → Resources
- RAM: 4GB → 8GB
- CPU: 2 cores → 4 cores
```

3. **Enable Redis caching:**
```bash
# Verify Redis is running
docker-compose ps redis

# Check Redis connection
docker-compose exec redis redis-cli ping
# Should return PONG
```

4. **Scale workers:**
```yaml
# In docker-compose.yml
worker:
  deploy:
    replicas: 3  # Increase from 1 to 3
```

---

## 🌐 Frontend Issues

### Problem: Can't Access http://localhost:3000

**Solutions:**

1. **Check frontend container:**
```bash
docker-compose logs frontend
docker-compose ps frontend
```

2. **Check node_modules:**
```bash
docker-compose exec frontend ls node_modules
# If empty, rebuild
docker-compose build frontend
docker-compose up -d frontend
```

3. **Clear browser cache:**
```
Cmd+Shift+R (Mac) or Ctrl+Shift+R (Windows)
```

4. **Check API connection:**
```
Frontend → Console (F12)
Look for CORS errors or failed API calls
```

---

## 🔒 Authentication Issues

### Problem: Can't Login

**Error:**
```
401 Unauthorized: Invalid credentials
```

**Solutions:**

1. **Reset admin password:**
```bash
docker-compose exec backend python -c "
from database import reset_admin_password
reset_admin_password('new_password_here')
"
```

2. **Check JWT secret:**
```bash
# Ensure SECRET_KEY is set in .env
cat .env | grep SECRET_KEY
```

3. **Clear cookies:**
```
Browser → Settings → Clear cookies for localhost
```

---

## 📊 Data Issues

### Problem: Missing Data

**Symptoms:**
- Agents list empty
- No tasks showing

**Solutions:**

1. **Run migrations:**
```bash
docker-compose exec backend alembic upgrade head
```

2. **Load sample data:**
```bash
docker-compose exec backend python demos/load_sample_data.py
```

3. **Check database:**
```bash
docker-compose exec postgres psql -U roady_user roady -c "
SELECT COUNT(*) FROM agents;
SELECT COUNT(*) FROM tasks;
"
```

---

## 🐳 Docker Issues

### Problem: Container Keeps Restarting

**Check logs:**
```bash
docker-compose logs --tail=100 backend
# Look for errors causing restart
```

**Common causes:**

1. **Port conflict:**
```bash
# Change port in docker-compose.yml
ports:
  - "8001:8000"  # Use 8001 instead of 8000
```

2. **Missing dependencies:**
```bash
# Rebuild container
docker-compose build --no-cache backend
docker-compose up -d backend
```

3. **Database not ready:**
```yaml
# Add depends_on with health check
depends_on:
  postgres:
    condition: service_healthy
```

---

## 🔍 Debugging Tips

### Enable Debug Mode

**Backend:**
```bash
# In .env
DEBUG=true
LOG_LEVEL=DEBUG

# Restart
docker-compose restart backend
```

**View detailed logs:**
```bash
docker-compose logs -f backend --tail=500
```

### Check Health Endpoints

```bash
# Backend health
curl http://localhost:8000/health

# Database health
curl http://localhost:8000/health/db

# Redis health
curl http://localhost:8000/health/redis
```

### Interactive Shell

```bash
# Access backend shell
docker-compose exec backend python

# Access database
docker-compose exec postgres psql -U roady_user roady
```

---

## 🆘 Still Need Help?

### Get Support

1. **Documentation:** http://docs.roady.ai
2. **Discord:** http://discord.gg/roady
3. **GitHub Issues:** http://github.com/your-org/roady/issues
4. **Email:** support@roady.ai

### Create Bug Report

```bash
# Via CLI
roady bug-report \
  --describe "Description of issue" \
  --include-logs

# Generates report.zip with:
# - Docker logs
# - System info
# - Configuration (sanitized)
```

### Useful Commands

```bash
# Full system reset
docker-compose down -v
rm -rf data/*
docker-compose up -d

# Check everything
docker-compose ps
docker-compose logs --tail=20
curl http://localhost:8000/health
curl http://localhost:3000

# Backup database
docker-compose exec postgres pg_dump -U roady_user roady > backup.sql
```

---

## ✅ Preventive Maintenance

### Weekly Tasks

- [ ] Check disk space: `df -h`
- [ ] Review error logs: `docker-compose logs | grep ERROR`
- [ ] Update dependencies: `docker-compose pull`
- [ ] Check budget usage
- [ ] Review agent quality ratings

### Monthly Tasks

- [ ] Backup database
- [ ] Review and optimize slow queries
- [ ] Update ROADY version
- [ ] Review security logs
- [ ] Clean up old logs/data

---

**Most issues can be resolved with a restart! 🔄**

When in doubt:
```bash
docker-compose restart
```
